CKEDITOR.skin.name = 'boltcke';
CKEDITOR.skin.ua_editor = 'ie,iequirks,ie7,ie8,gecko';
CKEDITOR.skin.ua_dialog = 'ie,iequirks,ie7,ie8,opera';
CKEDITOR.skin.chameleon = function() {
    return '';
};
