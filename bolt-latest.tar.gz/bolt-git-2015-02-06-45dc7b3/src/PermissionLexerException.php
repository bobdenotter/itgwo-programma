<?php

namespace Bolt;

use \Exception;

/**
 * Signals an error in the lexer.
 */
class PermissionLexerException extends Exception
{
}
