<?php

namespace Bolt;

use \Exception;

/**
 * Signals an error in the parser.
 */
class PermissionParserException extends Exception
{
}
