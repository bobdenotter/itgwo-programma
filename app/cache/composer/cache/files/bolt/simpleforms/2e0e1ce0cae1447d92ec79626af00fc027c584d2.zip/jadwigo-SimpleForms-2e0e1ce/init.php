<?php

use Bolt\Extension\Bolt\SimpleForms\Extension;

$app['extensions']->register(new Extension($app));
